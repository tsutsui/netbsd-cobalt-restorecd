#!/bin/sh

/bin/hostname
/usr/bin/awk '{ print $2 }' /etc/ifconfig.tlp0
